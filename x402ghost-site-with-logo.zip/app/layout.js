export const metadata = {
  title: "x402Ghost — Autonomous Agents that Pay and Coordinate",
  description: "A professional starter for economic multi‑agent systems built around HTTP 402 payments."
};
import "./globals.css";
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
